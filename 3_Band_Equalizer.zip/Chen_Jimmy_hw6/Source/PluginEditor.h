/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class Chen_Jimmy_hw6AudioProcessorEditor  : public juce::AudioProcessorEditor,
    private juce::Slider::Listener,
    private juce::ToggleButton::Listener
{
public:
    Chen_Jimmy_hw6AudioProcessorEditor (Chen_Jimmy_hw6AudioProcessor&);
    ~Chen_Jimmy_hw6AudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;
    
    typedef juce::AudioProcessorValueTreeState::SliderAttachment SliderAttachment;
    typedef juce::AudioProcessorValueTreeState::ButtonAttachment ButtonAttachment;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    Chen_Jimmy_hw6AudioProcessor& audioProcessor;
    
    //GUI Components
    juce::Label title;
    juce::Label lowTitle;
    juce::Label midTitle;
    juce::Label highTitle;
    
    juce::Label lowFreqTitle;
    juce::Label midFreqTitle;
    juce::Label highFreqTitle;
    juce::Slider lowFreqSlider;
    juce::Slider midFreqSlider;
    juce::Slider highFreqSlider;
    
    juce::Label lowGainTitle;
    juce::Label midGainTitle;
    juce::Label highGainTitle;
    juce::Slider lowGainSlider;
    juce::Slider midGainSlider;
    juce::Slider highGainSlider;
    
    juce::Label lowQTitle;
    juce::Label midQTitle;
    juce::Label highQTitle;
    juce::Slider lowQSlider;
    juce::Slider midQSlider;
    juce::Slider highQSlider;

    juce::ToggleButton lowShelf;
    juce::ToggleButton highShelf;
    
    // Attachments
    std::unique_ptr<SliderAttachment> lowFreqCutoffSliderAttachment;
    std::unique_ptr<SliderAttachment> midFreqCutoffSliderAttachment;
    std::unique_ptr<SliderAttachment> highFreqCutoffSliderAttachment;
    std::unique_ptr<SliderAttachment> lowQSliderAttachment;
    std::unique_ptr<SliderAttachment> midQSliderAttachment;
    std::unique_ptr<SliderAttachment> highQSliderAttachment;
    std::unique_ptr<SliderAttachment> lowGainSliderAttachment;
    std::unique_ptr<SliderAttachment> midGainSliderAttachment;
    std::unique_ptr<SliderAttachment> highGainSliderAttachment;
    std::unique_ptr<ButtonAttachment> ifLowShelfAttachment;
    std::unique_ptr<ButtonAttachment> ifHighShelfAttachment;

    
    void sliderValueChanged (juce::Slider * slider) override;
    void buttonClicked (juce::Button *) override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Chen_Jimmy_hw6AudioProcessorEditor)
};
