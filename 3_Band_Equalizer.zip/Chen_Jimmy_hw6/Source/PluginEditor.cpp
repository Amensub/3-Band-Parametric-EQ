/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
Chen_Jimmy_hw6AudioProcessorEditor::Chen_Jimmy_hw6AudioProcessorEditor (Chen_Jimmy_hw6AudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    auto height = 400;
    auto width = 1200;
    setSize(width, height);
    
    // Title Label Setup
    auto titleFont = juce::FontOptions("Times New Roman", 32.0f, juce::Font::bold);
    auto subTitleFont = juce::FontOptions("Times New Roman", 32.0f, juce::Font::bold);
    
    title.setText("3-Band Parametric EQ", juce::NotificationType::dontSendNotification);
    title.setJustificationType(juce::Justification::horizontallyCentred);
    title.setFont(titleFont);
    addAndMakeVisible(title);
    
    lowTitle.setText("Low", juce::NotificationType::dontSendNotification);
    lowTitle.setJustificationType(juce::Justification::horizontallyCentred);
    lowTitle.setFont(subTitleFont);
    addAndMakeVisible(lowTitle);
    
    midTitle.setText("Mid", juce::NotificationType::dontSendNotification);
    midTitle.setJustificationType(juce::Justification::horizontallyCentred);
    midTitle.setFont(subTitleFont);
    addAndMakeVisible(midTitle);
    
    highTitle.setText("High", juce::NotificationType::dontSendNotification);
    highTitle.setJustificationType(juce::Justification::horizontallyCentred);
    highTitle.setFont(subTitleFont);
    addAndMakeVisible(highTitle);
    
    // Low Shelf Toggle Setup
    lowShelf.setButtonText("Low Shelf");
    lowShelf.setClickingTogglesState(true);
    lowShelf.setToggleState(audioProcessor.lowShelfBool, juce::NotificationType::dontSendNotification);
    ifLowShelfAttachment.reset(new ButtonAttachment(audioProcessor.vtsLow, "ifLowShelf", lowShelf));
    addAndMakeVisible(lowShelf);
    
    // High Shelf Toggle Setup
    highShelf.setButtonText("High Shelf");
    highShelf.setClickingTogglesState(true);
    highShelf.setToggleState(audioProcessor.highShelfBool, juce::NotificationType::dontSendNotification);
    ifHighShelfAttachment.reset(new ButtonAttachment(audioProcessor.vtsLow, "ifHighShelf", highShelf));
    addAndMakeVisible(highShelf);
    
    // lowFreq Slider Setup
    lowFreqSlider.setSliderStyle(juce::Slider::Rotary);
    lowFreqSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    lowFreqSlider.setTextValueSuffix(" Hz");
    lowFreqSlider.setRange(10, 1000, 500);
    lowFreqCutoffSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "lowFreqCutoff", lowFreqSlider));
    lowFreqSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    lowFreqSlider.setValue(audioProcessor.lowFreq);
    addAndMakeVisible(lowFreqSlider);
    
    // lowFreq Label Setup
    lowFreqTitle.setText("Frequency", juce::dontSendNotification);
    lowFreqTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    lowFreqTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(lowFreqTitle);
    
    // midFreq Slider Setup
    midFreqSlider.setSliderStyle(juce::Slider::Rotary);
    midFreqSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    midFreqSlider.setTextValueSuffix(" Hz");
    midFreqSlider.setRange(500, 5000, 2000);
    midFreqCutoffSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "midFreqCutoff", midFreqSlider));
    midFreqSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    midFreqSlider.setValue(audioProcessor.highFreq);
    addAndMakeVisible(midFreqSlider);
    
    // midFreq Label Setup
    midFreqTitle.setText("Frequency", juce::dontSendNotification);
    midFreqTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    midFreqTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(midFreqTitle);
    
    // highFreq Slider Setup
    highFreqSlider.setSliderStyle(juce::Slider::Rotary);
    highFreqSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    highFreqSlider.setTextValueSuffix(" Hz");
    highFreqSlider.setRange(2000, 10000, 5000);
    highFreqCutoffSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "highFreqCutoff", highFreqSlider));
    highFreqSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    highFreqSlider.setValue(audioProcessor.highFreq);
    addAndMakeVisible(highFreqSlider);
    
    // highFreq Label Setup
    highFreqTitle.setText("Frequency", juce::dontSendNotification);
    highFreqTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    highFreqTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(highFreqTitle);
    
    // lowGain Slider Setup
    lowGainSlider.setSliderStyle(juce::Slider::Rotary);
    lowGainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    lowGainSlider.setTextValueSuffix("dB");
    lowGainSlider.setRange(-20, 20, 0);
    lowGainSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    lowGainSlider.setValue(audioProcessor.lowGain);
    addAndMakeVisible(lowGainSlider);
    
    // lowGain Label Setup
    lowGainTitle.setText("Gain", juce::dontSendNotification);
    lowGainTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    lowGainTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(lowGainTitle);
    
    // midGain Slider Setup
    midGainSlider.setSliderStyle(juce::Slider::Rotary);
    midGainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    midGainSlider.setTextValueSuffix("dB");
    midGainSlider.setRange(-20, 20, 0);
    midGainSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    midGainSlider.setValue(audioProcessor.midGain);
    addAndMakeVisible(midGainSlider);
    
    // midGain Label Setup
    midGainTitle.setText("Gain", juce::dontSendNotification);
    midGainTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    midGainTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(midGainTitle);
    
    // highGain Slider Setup
    highGainSlider.setSliderStyle(juce::Slider::Rotary);
    highGainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    highGainSlider.setTextValueSuffix("dB");
    highGainSlider.setRange(-20, 20, 0);
    highGainSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    highGainSlider.setValue(audioProcessor.highGain);
    addAndMakeVisible(highGainSlider);
    
    // highGain Label Setup
    highGainTitle.setText("Gain", juce::dontSendNotification);
    highGainTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    highGainTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(highGainTitle);
    
    // lowQ Slider Setup
    lowQSlider.setSliderStyle(juce::Slider::Rotary);
    lowQSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    //lowQSlider.setRange(0.1, 10.0, 1.0);
    lowQSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "lowQ", lowQSlider));
    lowQSlider.setSkewFactorFromMidPoint(1.0);
    lowQSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    lowQSlider.setValue(audioProcessor.lowQ);
    addAndMakeVisible(lowQSlider);
    
    // lowQ Label Setup
    lowQTitle.setText("Q", juce::dontSendNotification);
    lowQTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    lowQTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(lowQTitle);
    
    // midQ Slider Setup
    midQSlider.setSliderStyle(juce::Slider::Rotary);
    midQSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    midQSlider.setRange(0.1, 10.0, 1.0);
    midQSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "midQ", midQSlider));
    midQSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    midQSlider.setValue(audioProcessor.midQ);
    addAndMakeVisible(midQSlider);
    
    // midQ Label Setup
    midQTitle.setText("Q", juce::dontSendNotification);
    midQTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    midQTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(midQTitle);
    
    // highQ Slider Setup
    highQSlider.setSliderStyle(juce::Slider::Rotary);
    highQSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, true, width * 0.2, height * 0.05);
    highQSlider.setRange(0.1, 10.0, 1.0);
    highQSliderAttachment.reset(new SliderAttachment(audioProcessor.vtsLow, "highQ",highQSlider));
    highQSlider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    highQSlider.setValue(audioProcessor.highQ);
    addAndMakeVisible(highQSlider);
    
    // highQ Label Setup
    highQTitle.setText("Q", juce::dontSendNotification);
    highQTitle.setFont(juce::FontOptions("Times New Roman", 20.0f, juce::Font::plain));
    highQTitle.setJustificationType(juce::Justification::horizontallyCentred);
    addAndMakeVisible(highQTitle);
    
    // Add Listeners
    lowFreqSlider.addListener(this);
    midFreqSlider.addListener(this);
    highFreqSlider.addListener(this);
    
    lowGainSlider.addListener(this);
    midGainSlider.addListener(this);
    highGainSlider.addListener(this);
    
    lowQSlider.addListener(this);
    midQSlider.addListener(this);
    highQSlider.addListener(this);
    
    lowShelf.addListener(this);
    highShelf.addListener(this);
}

Chen_Jimmy_hw6AudioProcessorEditor::~Chen_Jimmy_hw6AudioProcessorEditor()
{
}

//==============================================================================
void Chen_Jimmy_hw6AudioProcessorEditor::paint (juce::Graphics& g)
{
    //Set up the different areas
    auto border = 5;
    auto bg = getLocalBounds().reduced(0); //fill background color
    auto area = getLocalBounds().reduced(border * 4);
    auto titleArea = area.removeFromTop(0.25 * area.getHeight());
    auto parameterArea = area.removeFromBottom(0.9 * area.getHeight());
    
    //Fill the areas with different colors
    g.setColour(juce::Colours::honeydew);
    g.fillRect(bg);
    g.setColour(juce::Colours::pink);
    g.fillRect(titleArea);
    
    auto lowArea = parameterArea.removeFromLeft(0.3333 * parameterArea.getWidth());
    g.setColour(juce::Colours::peachpuff);
    g.fillRect(lowArea);
    
    auto midArea = parameterArea.removeFromLeft(0.5 * parameterArea.getWidth());
    g.setColour(juce::Colours::aquamarine);
    g.fillRect(midArea);
    
    auto highArea = parameterArea;
    g.setColour(juce::Colours::palegreen);
    g.fillRect(highArea);
}

void Chen_Jimmy_hw6AudioProcessorEditor::resized()
{
    //Set up the different areas
    auto border = 5;
    auto area = getLocalBounds().reduced(border * 4);
    auto titleArea = area.removeFromTop(0.25 * area.getHeight());
    auto parameterArea = area.removeFromBottom(0.9 * area.getHeight());
    
    auto lowArea = parameterArea.removeFromLeft(0.3333 * parameterArea.getWidth());
    auto lowTitleA = lowArea.removeFromTop(0.3 * lowArea.getHeight());
    auto lowShelfA = lowArea.removeFromTop(0.1 * lowArea.getHeight());
    
    auto lowFreqA = lowArea.removeFromLeft(0.3333 * lowArea.getWidth());
    auto lowFreqTitleA = lowFreqA.removeFromTop(0.2 * lowFreqA.getHeight());
    auto lowFreqSliderA = lowFreqA;
    auto lowGainA= lowArea.removeFromLeft(0.5 * lowArea.getWidth());
    auto lowGainTitleA = lowGainA.removeFromTop(0.2 * lowGainA.getHeight());
    auto lowGainSliderA = lowGainA;
    auto lowQA = lowArea;
    auto lowQTitleA = lowQA.removeFromTop(0.2 * lowQA.getHeight());
    auto lowQSliderA = lowQA;

    auto midArea = parameterArea.removeFromLeft(0.5 * parameterArea.getWidth());
    auto midTitleA = midArea.removeFromTop(0.3 * midArea.getHeight());
    auto midParameterA = midArea.removeFromBottom(0.9 * midArea.getHeight());
    
    auto midFreqA = midParameterA.removeFromLeft(0.3333 * midParameterA.getWidth());
    auto midFreqTitleA = midFreqA.removeFromTop(0.2 * midFreqA.getHeight());
    auto midFreqSliderA = midFreqA;
    auto midGainA= midParameterA.removeFromLeft(0.5 * midParameterA.getWidth());
    auto midGainTitleA = midGainA.removeFromTop(0.2 * midGainA.getHeight());
    auto midGainSliderA = midGainA;
    auto midQA = midParameterA;
    auto midQTitleA = midQA.removeFromTop(0.2 * midQA.getHeight());
    auto midQSliderA = midQA;
    
//    DBG("midAreaHeight=" << midTitleA.getHeight());
//    DBG("lowAreaHeight=" << lowTitleA.getHeight());
    
    auto highArea = parameterArea;
    auto highTitleA = highArea.removeFromTop(0.3 * highArea.getHeight());
    auto highShelfA = highArea.removeFromTop(0.1 * highArea.getHeight());
    
    auto highFreqA = highArea.removeFromLeft(0.3333 * highArea.getWidth());
    auto highFreqTitleA = highFreqA.removeFromTop(0.2 * highFreqA.getHeight());
    auto highFreqSliderA = highFreqA;
    auto highGainA= highArea.removeFromLeft(0.5 * highArea.getWidth());
    auto highGainTitleA = highGainA.removeFromTop(0.2 * highGainA.getHeight());
    auto highGainSliderA = highGainA;
    auto highQA = highArea;
    auto highQTitleA = highQA.removeFromTop(0.2 * highQA.getHeight());
    auto highQSliderA = highQA;
    
    title.setBounds(titleArea);
    lowTitle.setBounds(lowTitleA);
    midTitle.setBounds(midTitleA);
    highTitle.setBounds(highTitleA);
    
    lowShelf.setBounds(lowShelfA);
    highShelf.setBounds(highShelfA);
    
    lowFreqTitle.setBounds(lowFreqTitleA);
    lowFreqSlider.setBounds(lowFreqSliderA);
    midFreqTitle.setBounds(midFreqTitleA);
    midFreqSlider.setBounds(midFreqSliderA);
    highFreqTitle.setBounds(highFreqTitleA);
    highFreqSlider.setBounds(highFreqSliderA);
    
    lowGainTitle.setBounds(lowGainTitleA);
    lowGainSlider.setBounds(lowGainSliderA);
    midGainTitle.setBounds(midGainTitleA);
    midGainSlider.setBounds(midGainSliderA);
    highGainTitle.setBounds(highGainTitleA);
    highGainSlider.setBounds(highGainSliderA);
    
    lowQTitle.setBounds(lowQTitleA);
    lowQSlider.setBounds(lowQSliderA);
    midQTitle.setBounds(midQTitleA);
    midQSlider.setBounds(midQSliderA);
    highQTitle.setBounds(highQTitleA);
    highQSlider.setBounds(highQSliderA);
}

void Chen_Jimmy_hw6AudioProcessorEditor::sliderValueChanged (juce::Slider* slider)
{
    if(slider == &lowFreqSlider){   // thresholdSlider
        audioProcessor.lowFreq = slider->getValue();
        DBG("Low Pass Frequency = " << audioProcessor.lowFreq << " Hz");
    }
    else if(slider == &midFreqSlider){   // ratioSlider
        audioProcessor.midFreq = slider->getValue();
        DBG("Mid Pass Frequency = " << audioProcessor.midFreq << " Hz");
    }
    else if(slider == &highFreqSlider){   // attackSlider
        audioProcessor.highFreq = slider->getValue();
        DBG("High Pass Frequency = " << audioProcessor.highFreq << " Hz");
    }
    else if(slider == &lowGainSlider){   // ratioSlider
        audioProcessor.lowGain = slider->getValue();
        DBG("Low Psas Gain = " << audioProcessor.lowGain << "dB");
    }
    else if(slider == &midGainSlider){   // attackSlider
        audioProcessor.midGain = slider->getValue();
        DBG("Mid Pass Gain = " << audioProcessor.midGain << "dB");
    }
    else if(slider == &highGainSlider){   // attackSlider
        audioProcessor.highGain = slider->getValue();
        DBG("High Pass Gain = " << audioProcessor.highGain << "dB");
    }
    else if(slider == &lowQSlider){   // ratioSlider
        audioProcessor.lowQ = slider->getValue();
        DBG("Low Psas Q Factor = " << audioProcessor.lowQ);
    }
    else if(slider == &midQSlider){   // attackSlider
        audioProcessor.midQ = slider->getValue();
        DBG("Mid Pass Q Factor = " << audioProcessor.midQ);
    }
    else if(slider == &highQSlider){   // attackSlider
        audioProcessor.highQ = slider->getValue();
        DBG("High Pass Q Factor = " << audioProcessor.highQ);
    }
}

void Chen_Jimmy_hw6AudioProcessorEditor::buttonClicked (juce::Button * button)
{
    if(button == &lowShelf){   // mute ToggleButton
        if(lowShelf.getToggleState() == true){
            audioProcessor.lowShelfBool = true;
            DBG("Low Shelf Selected");
        }
        else{
            audioProcessor.lowShelfBool = false;
            DBG("Low Shelf Deselected");
        }
    }
    else if (button == &highShelf){   // bypass ToggleButton
        if(highShelf.getToggleState() == true){
            audioProcessor.highShelfBool = true;
            DBG("High Shelf Selected");
        }
        else{
            audioProcessor.highShelfBool= false;
            DBG("High Shelf Deselected");
        }
    }
}
