/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
Chen_Jimmy_hw6AudioProcessor::Chen_Jimmy_hw6AudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )

, vtsLow(*this, nullptr, juce::Identifier("lowPassFilter"), {
                      std::make_unique<juce::AudioParameterFloat> (
     juce::ParameterID("lowFreqCutoff", 1),         // parameterID
                      "LowFreqCutoff",              // parameter name
                      10.0f,                 // minimum value
                      1000.0f,              // maximum value
                      500.0f)                // default value
                    ,
                      std::make_unique<juce::AudioParameterFloat> (
     juce::ParameterID("lowQ", 1),             // parameterID
                      "LowQ",                  // parameter name
                      0.1f,                 // minimum value
                      10.0f,                // maximum value
                      1.0)                 // default value
                    ,
                      std::make_unique<juce::AudioParameterInt> (
     juce::ParameterID("lowGain", 1),             // parameterID
                      "LowGain",                  // parameter name
                      -20,                 // minimum value
                      20,                // maximum value
                      0)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterBool> (
    juce::ParameterID("ifLowShelf", 1),     // parameterID
                     "IfLowShelf",      // parameter name
                     1)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterFloat> (
    juce::ParameterID("midFreqCutoff", 1),         // parameterID
                     "MidFreqCutoff",              // parameter name
                     500.0f,                 // minimum value
                     5000.0f,              // maximum value
                     2000.0f)                // default value
                   ,
                     std::make_unique<juce::AudioParameterFloat> (
    juce::ParameterID("midQ", 1),             // parameterID
                     "MidQ",                  // parameter name
                     0.1f,                 // minimum value
                     10.0f,                // maximum value
                     1.0)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterInt> (
    juce::ParameterID("midGain", 1),             // parameterID
                     "MidGain",                  // parameter name
                     -20,                 // minimum value
                     20,                // maximum value
                     0)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterFloat> (
    juce::ParameterID("highFreqCutoff", 1),         // parameterID
                     "HighFreqCutoff",              // parameter name
                     2000.0f,                 // minimum value
                     10000.0f,              // maximum value
                     5000.0f)                // default value
                   ,
                     std::make_unique<juce::AudioParameterFloat> (
    juce::ParameterID("highQ", 1),             // parameterID
                     "HighQ",                  // parameter name
                     0.1f,                 // minimum value
                     10.0f,                // maximum value
                     1.0)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterInt> (
    juce::ParameterID("highGain", 1),             // parameterID
                     "HighGain",                  // parameter name
                     -20,                 // minimum value
                     20,                // maximum value
                     0)                 // default value
                   ,
                     std::make_unique<juce::AudioParameterBool> (
   juce::ParameterID("ifHighShelf", 1),     // parameterID
                     "IfHighShelf",      // parameter name
                     1)

                   }
                 )

#endif
{
    DBG("PluginProcessor Constructor");
    
    // also inititalize the pointers
    lowFreqCutoffParameter = vtsLow.getRawParameterValue("lowFreqCutoff");
    lowQParameter = vtsLow.getRawParameterValue("lowQ");
    lowGainParameter = vtsLow.getRawParameterValue("lowGain");
    ifLowShelfParameter = vtsLow.getRawParameterValue("ifLowShelf");
    
    midFreqCutoffParameter = vtsLow.getRawParameterValue("midFreqCutoff");
    midQParameter = vtsLow.getRawParameterValue("midQ");
    midGainParameter = vtsLow.getRawParameterValue("midGain");
    
    highFreqCutoffParameter = vtsLow.getRawParameterValue("highFreqCutoff");
    highQParameter = vtsLow.getRawParameterValue("highQ");
    highGainParameter = vtsLow.getRawParameterValue("highGain");
    ifHighShelfParameter = vtsLow.getRawParameterValue("ifHighShelf");
}

Chen_Jimmy_hw6AudioProcessor::~Chen_Jimmy_hw6AudioProcessor()
{
}

//==============================================================================
const juce::String Chen_Jimmy_hw6AudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool Chen_Jimmy_hw6AudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool Chen_Jimmy_hw6AudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool Chen_Jimmy_hw6AudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double Chen_Jimmy_hw6AudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int Chen_Jimmy_hw6AudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int Chen_Jimmy_hw6AudioProcessor::getCurrentProgram()
{
    return 0;
}

void Chen_Jimmy_hw6AudioProcessor::setCurrentProgram (int index)
{
}

const juce::String Chen_Jimmy_hw6AudioProcessor::getProgramName (int index)
{
    return {};
}

void Chen_Jimmy_hw6AudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void Chen_Jimmy_hw6AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = getTotalNumInputChannels();
    
    stateVariableTPTFilterLow.prepare(spec);
    updateParameters();
    stateVariableTPTFilterLow.reset();
    
    stateVariableTPTFilterMid.prepare(spec);
    updateParameters();
    stateVariableTPTFilterMid.reset();
    
    stateVariableTPTFilterHigh.prepare(spec);
    updateParameters();
    stateVariableTPTFilterHigh.reset();
}

void Chen_Jimmy_hw6AudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool Chen_Jimmy_hw6AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void Chen_Jimmy_hw6AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    juce::dsp::AudioBlock<float> block(buffer);
    
    updateParameters();
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        for(int i = 0; i < buffer.getNumSamples(); i++)
        {
            float in = channelData[i]; // each sample

            // Apply filters
            float lowO = stateVariableTPTFilterLow.processSample(channel, in);
            float midO = stateVariableTPTFilterMid.processSample(channel, in);
            float highO = stateVariableTPTFilterHigh.processSample(channel, in);
            
            channelData[i] = lowO * lowGain + midO * midGain + highO * highGain;
        }
    }
}

//==============================================================================
bool Chen_Jimmy_hw6AudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* Chen_Jimmy_hw6AudioProcessor::createEditor()
{
    return new Chen_Jimmy_hw6AudioProcessorEditor (*this);
}

//==============================================================================
void Chen_Jimmy_hw6AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    DBG("getStateInformation");
    auto stateLow = vtsLow.copyState();  // parametersTreeState
    // each state is a value tree for a band
    std::unique_ptr<juce::XmlElement> xmlLow(stateLow.createXml());   // a pointer object
    copyXmlToBinary(*xmlLow, destData);
}

void Chen_Jimmy_hw6AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    DBG("setStateInformation");
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState.get() != nullptr)
         if (xmlState->hasTagName(vtsLow.state.getType()))
               vtsLow.replaceState (juce::ValueTree::fromXml(*xmlState));
}

//==============================================================================
// This creates new instances of the plugin..

void Chen_Jimmy_hw6AudioProcessor::updateParameters()
{
    bool ifLowShelf = *vtsLow.getRawParameterValue("ifLowShelf");
    float lowFreqCutoff = *vtsLow.getRawParameterValue("lowFreqCutoff");
    float lowGain = *vtsLow.getRawParameterValue("lowGain");
    float lowQ = *vtsLow.getRawParameterValue("lowQ");
    
    float midFreqCutoff = *vtsLow.getRawParameterValue("midFreqCutoff");
    float midGain = *vtsLow.getRawParameterValue("midGain");
    float midQ = *vtsLow.getRawParameterValue("midQ");
    
    bool ifHighShelf = *vtsLow.getRawParameterValue("ifHighShelf");
    float highFreqCutoff = *vtsLow.getRawParameterValue("highFreqCutoff");
    float highGain = *vtsLow.getRawParameterValue("highGain");
    float highQ = *vtsLow.getRawParameterValue("highQ");
    
    if(ifLowShelf)
    {
        stateVariableTPTFilterLow.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    }
    else
    {
        stateVariableTPTFilterLow.setType(juce::dsp::StateVariableTPTFilterType::bandpass);
    }
    stateVariableTPTFilterLow.setResonance(lowQ);
    stateVariableTPTFilterLow.setCutoffFrequency(lowFreqCutoff);
    
    stateVariableTPTFilterMid.setType(juce::dsp::StateVariableTPTFilterType::bandpass);
    stateVariableTPTFilterMid.setResonance(midQ);
    stateVariableTPTFilterMid.setCutoffFrequency(midFreqCutoff);
    
    if(ifHighShelf)
    {
        stateVariableTPTFilterHigh.setType(juce::dsp::StateVariableTPTFilterType::highpass);
    }
    else
    {
        stateVariableTPTFilterHigh.setType(juce::dsp::StateVariableTPTFilterType::bandpass);
    }
    stateVariableTPTFilterHigh.setResonance(highQ);
    stateVariableTPTFilterHigh.setCutoffFrequency(highFreqCutoff);
}


juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new Chen_Jimmy_hw6AudioProcessor();
}
