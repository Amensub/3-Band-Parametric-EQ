/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>

//==============================================================================
/**
*/
class Chen_Jimmy_hw6AudioProcessor  : public juce::AudioProcessor
{
public:
    //==============================================================================
    Chen_Jimmy_hw6AudioProcessor();
    ~Chen_Jimmy_hw6AudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;
    
    // was planning to add AudioProcessorValueTreeState objects for each band, but finally decided to store everything in one value tree, doesn't want to change the name so that it runds without errors
    juce::AudioProcessorValueTreeState vtsLow;
//    juce::AudioProcessorValueTreeState vtsMid;
//    juce::AudioProcessorValueTreeState vtsHigh;
    
    float lowFreq;
    float midFreq;
    float highFreq;
    
    float lowGain;
    float midGain;
    float highGain;
    
    float lowQ;
    float midQ;
    float highQ;
    
    bool lowShelfBool;
    bool highShelfBool;
    
    void updateParameters(); // updateParameters for FIR_LPF_Duplicator

private:
    // for sample rate and block size
    juce::dsp::ProcessSpec spec;
    //==============================================================================
    
    juce::dsp::StateVariableTPTFilter<float> stateVariableTPTFilterLow; // Add dsp::ProcessorDuplicator with dsp::StateVariableTPTFilter<float>
    juce::dsp::StateVariableTPTFilter<float> stateVariableTPTFilterMid;
    juce::dsp::StateVariableTPTFilter<float> stateVariableTPTFilterHigh;
    
    std::atomic<float> * lowFreqCutoffParameter = nullptr;
    std::atomic<float> * lowQParameter = nullptr;
    std::atomic<float> * lowGainParameter = nullptr;
    std::atomic<float> * ifLowShelfParameter = nullptr;
    
    std::atomic<float> * midFreqCutoffParameter = nullptr;
    std::atomic<float> * midQParameter = nullptr;
    std::atomic<float> * midGainParameter = nullptr;
    
    std::atomic<float> * highFreqCutoffParameter = nullptr;
    std::atomic<float> * highQParameter = nullptr;
    std::atomic<float> * highGainParameter = nullptr;
    std::atomic<float> * ifHighShelfParameter = nullptr;
    
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Chen_Jimmy_hw6AudioProcessor)
};
